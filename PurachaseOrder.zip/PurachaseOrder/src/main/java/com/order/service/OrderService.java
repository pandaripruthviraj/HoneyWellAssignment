package com.order.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.order.dao.OrderDao;
import com.order.model.Order;

@Service
public class OrderService {
	
	@Autowired
	OrderDao orderDao;
	
	public Order save(Order newOrder) {
		return orderDao.save(newOrder);
	}
}
