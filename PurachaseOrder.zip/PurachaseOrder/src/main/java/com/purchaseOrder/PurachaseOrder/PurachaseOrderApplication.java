package com.purchaseOrder.PurachaseOrder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PurachaseOrderApplication {

	public static void main(String[] args) {
		SpringApplication.run(PurachaseOrderApplication.class, args);
	}

}
