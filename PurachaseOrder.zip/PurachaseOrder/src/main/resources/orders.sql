DROP TABLE IF EXISTS TBL_ORDERS;
  
CREATE TABLE TBL_USERS (
  id INT AUTO_INCREMENT  PRIMARY KEY,
  first_name VARCHAR(50) NOT NULL,
  last_name VARCHAR(50) NOT NULL,
  email VARCHAR(100) DEFAULT NULL,
  orderDetails VARCHAR(200) DEFAULT NULL
);

INSERT INTO TBL_USERS (id, first_name, last_name, email, orderDetails) VALUES (1, 'Pruthvi', 'Hyderabad', 'a@mail.com', '"{\"Order\":{\"Item\":{\"name\":\"Pizza\",\"price\":200}}}"');