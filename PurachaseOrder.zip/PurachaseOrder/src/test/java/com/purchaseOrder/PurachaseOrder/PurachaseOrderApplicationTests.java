package com.purchaseOrder.PurachaseOrder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PurachaseOrderApplicationTests {

	@Test
	void contextLoads() {
	}

}
